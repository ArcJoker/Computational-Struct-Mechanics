function eleStff = ElementStiffnessMatrixElasticity2D(coordEle, D)
%% Element stiffness matrix

%nodal coordinates
x1 = coordEle(1,1); y1 = coordEle(1,2); 
x2 = coordEle(2,1); y2 = coordEle(2,2); 
x3 = coordEle(3,1); y3 = coordEle(3,2); 

%B-matrix
a2 = x2*y3-x3*y2 + x3*y1-x1*y3 + x1*y2-x2*y1;
B = ElementBMatrixElasticity2DTri3(coordEle);

%Stiffness matrix
eleStff = B'*D*B*(a2/2) ; %To be continued by student
end
