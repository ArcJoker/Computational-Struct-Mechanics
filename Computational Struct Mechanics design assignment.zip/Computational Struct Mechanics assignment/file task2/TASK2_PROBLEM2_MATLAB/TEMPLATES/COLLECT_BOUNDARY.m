function [OLIS]=COLLECT_BOUNDARY(ILIS,VERTICES,EDGES,COORD,LINE)

% OUTPUTS BOUNDARY CONDITION NODES IN THE DIRECTION OF THE DEFINED LINE

SMALL=1E-8;

OLIS=[];

for IL=1:size(ILIS,1);
    TEMP=[];
    LINO= ILIS(IL,1);
    LCON=LINE(LINO,:);
        
    X1=COORD(LCON(1,1),1); Y1=COORD(LCON(1,1),2);
    X2=COORD(LCON(1,2),1); Y2=COORD(LCON(1,2),2);
    
    YMAX=max(Y1,Y2);     YMIN=min(Y1,Y2);
    XMAX=max(X1,X2);     XMIN=min(X1,X2);
    
    for IE=1:size(EDGES,1);
        EDGE=[EDGES(IE,1) EDGES(IE,2)];
        
        KOUNT=0;
        for IEE=1:size(EDGE,2);
            ON_EDGE=0;
            X0=VERTICES(EDGE(1,IEE),1); Y0=VERTICES(EDGE(1,IEE),2);
            
            if abs(X2-X1)<=SMALL
                if abs(X0-X1)<=SMALL
                    ON_EDGE=1;
                end
            else
                YTEMP=(Y2-Y1)*(X0-X1)/(X2-X1)+Y1;
                if abs(YTEMP-Y0)<=SMALL
                    ON_EDGE=1;
                end
            end
            
            if X0>XMAX+SMALL || X0<XMIN-SMALL || Y0>YMAX+SMALL ||...
                    Y0<YMIN-SMALL
                ON_EDGE=0;
            end
            
            if ON_EDGE==1
                KOUNT=KOUNT+1;
            end
        end
        
        if KOUNT==2
            % THE CURRENT EDGE LIES ON THE PRIMARY LINE
            TEMP=[TEMP IE];
        end
    end
    
    % OBTAIN THE NODES ON THIS EDGE
    SCTR=EDGES(TEMP,:);
    ECTR=[];
    for I=1:size(SCTR,1);
        ECTR=[ECTR SCTR(I,:)];
    end
    [SCTR]=FILTER_REPEATED_IDENTITIES(ECTR);        
    NCTR=SCTR;
    SCTR=VERTICES(SCTR,:);    
    
    % SORT THE COORDINATES IN THE ORDER OF THE LINE DEFINED
    if abs(SCTR(1,1)-X1)<=SMALL && abs(SCTR(1,2)-Y1)<=SMALL
        
        % NODE COINCIDENT - DO NOTHING
    else        
        
        % NODE NOT COINCIDENT. REVERSE ORDERING
        VCTR=SCTR;
        NV  =size(VCTR,1);
        SCTR=SCTR(NV:-1:1,:);
        NCTR=NCTR(1,NV:-1:1);
        
    end
    
    
    % GENERATE EDGELIST FROM NODE LIST
    ECTR=[];
    for J=1:size(NCTR,2)-1;
        ECTR=[ECTR; NCTR(1,J) NCTR(1,J+1)];
    end
    
    
    % CREATE THE OUTPUT LIST FOR THIS BOUNDARY CONDITION
    OLIS(IL).EDGES=ECTR;
    OLIS(IL).COORD=SCTR;
    OLIS(IL).NODES=NCTR;
    OLIS(IL).VALUE=ILIS(IL,2);  

end