function PLOTMESH(NLIST,ELIST, PlotCntrl)

% THIS FUNCTION PLOTS THE DISPLACED FEM MESH

if nargin <3
    PlotCntrl.lettering = 1;
    PlotCntrl.markersize = 10;
end
if isfield(PlotCntrl, 'markersize')
    markersize = PlotCntrl.markersize;
else
    markersize = 10;
end 

NNODE=size(ELIST,2);
NDIME=size(NLIST,2);

XMAX=max(NLIST(:,1)); YMAX=max(NLIST(:,2));
XMIN=min(NLIST(:,1)); YMIN=min(NLIST(:,2));

XPLUS=0.05*(XMAX-XMIN);
YPLUS=0.05*(YMAX-YMIN);

OFFSETX=0.005*(XMAX-XMIN);
OFFSETY=0.005*(YMAX-YMIN);

figure(1);
for IELEM=1:size(ELIST,1);
    LNODS=ELIST(IELEM,:);
    
    ELCOD=zeros(size(LNODS,2),NDIME);
    for I=1:size(ELCOD,1);
        ELCOD(I,:)=NLIST(LNODS(1,I),:);
    end
    
    ELCOD=[ELCOD; ELCOD(1,:)];
    plot(ELCOD(:,1),ELCOD(:,2),'-bo','markerfacecolor','y','markersize',markersize,'linewidth',0.5);
    
    if PlotCntrl.lettering
        for IL=1:size(LNODS,2);
            text(ELCOD(IL,1)+OFFSETX,ELCOD(IL,2)-OFFSETY,int2str(LNODS(IL)),'FontSize',12,'Color','k');
            hold on;
        end
        
        CENTRE=[mean(ELCOD(1:size(LNODS,2),1)) mean(ELCOD(1:size(LNODS,2),2))];
        text(CENTRE(1),CENTRE(2),int2str(IELEM),'FontSize',12,'Color','r');
        
    end
    
    hold on;
end



axis equal
axis ([XMIN-XPLUS XMAX+XPLUS YMIN-YPLUS YMAX+YPLUS])