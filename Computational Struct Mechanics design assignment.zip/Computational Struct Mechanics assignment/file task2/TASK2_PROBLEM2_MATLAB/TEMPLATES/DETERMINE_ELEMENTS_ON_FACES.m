function [EFLIST]=DETERMINE_ELEMENTS_ON_FACES(NLIST,ELIST,CENTRES,COORD,LINE,FACE)

NFACE=size(FACE,2);
for IF=1:size(FACE,2);
    LCTR=FACE{IF};
    NCTR=[];
    for IL=1:size(LCTR,2);
        NCTR=[NCTR LINE(LCTR(1,IL),:)];
    end
    [NCTR]=FILTER_REPEATED_IDENTITIES(NCTR);
    XV=COORD(NCTR,1);
    YV=COORD(NCTR,2);
    
    TEMP=[];
    for IE=1:size(ELIST,1);
        ELCOD=NLIST(ELIST(IE,:),:);
        CENTRE=CENTRES(IE,:);
        IN=inpolygon(CENTRE(1),CENTRE(2),XV,YV);
        if IN==1
            TEMP=[TEMP IE];
        end
    end
    EFLIST{IF}=TEMP;    
end