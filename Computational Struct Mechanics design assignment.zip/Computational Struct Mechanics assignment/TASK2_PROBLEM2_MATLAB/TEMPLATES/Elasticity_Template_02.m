clear all; %clear all variables
close all; %close all figures
warning('off','all'); clc;
dbstop if error

% SET THE PATHS TO THE FOLDERS (to be replaced by student)
addpath(genpath('C:\Users\Danie\Google Drive\CVEN9820\Assignment\CVEN9820_Assign_TASK2_Problem2\CVEN4304.MTLB.CODE\ELAS2D\TEMPLATES'));

%%%%%%%%% INPUTS  %%%%%%%%

% INPUT MAXIMUM SIZE OF TRIANGULAR ELEMENT
hdata.hmax = 0.25;

% DEFINE THE SEMI-CIRCLE
radius = 4; 
xcentre = 7; ycentre = 2;
nSegment = ceil(pi*radius/hdata.hmax/2);
dltTheta = pi/(nSegment);

% INPUT VECTOR OF POINTS
POINT=[ 11  0;
        14  0;
        14  8;
        7   8;
        0   8;
        0   0; 
        3   0;  
        [ xcentre+radius*cos(pi:-dltTheta:-0.1*dltTheta); % the "-0.1*dltTheta" is to ensure the point at Theta =0 is included
          ycentre+radius*sin(pi:-dltTheta:-0.1*dltTheta)]'
 ];
   
% INPUT LINE-COORDINATE CONNECTIVITY
nPoint = size(POINT,1);
LINE = [ [1:nPoint-1; 2:nPoint]'; nPoint 1];

% INPUT FACE-LINE CONNECTIVITY
FACE{1} = [1:size(LINE,1)];

MaterialInFace = [ 1 ]; % specify the material in a face


%% Material definitions 
mat(1).E = 21e6;    %E: Young's modulus
mat(1).pos = 0.25; %pos: Poisson's ratio
mat(1).plane = 2;  %plane = 1: plane stress
                   %      = 2: plane strain

%% Boundary condition
GivenTracOnLine = [3     0     -304; ...
                   2   -108      0  ]; % line, x-traction y-traction. One row per edge
GivenDispOnLine = [1  1  0; ...
                   1  2  0; ...
                   6  1  0; ...
                   6  2  0]; %line, direction and displacement. One row per DOF
 
%% 
%%%%%%  GENERATE THE FINITE ELEMENT MESH %%%%%
[coord, EleConnTbl,NodesOnLine, EdgesOnLine,ElementsOnFace]...
                                     = FEMPREPROS(POINT,LINE,FACE,hdata);

nNode = size(coord,1); % number of nodes in mesh                              
nEle = size(EleConnTbl,1); % number of elements in mesh                              

% plot mesh
if size(EleConnTbl,1) > 50
    PlotCntrl.lettering = 0; % = 0 do not show nodal and element numbers; = 1 show
else
    PlotCntrl.lettering = 1; % = 0 do not show nodal and element numbers; = 1 show
end
PlotCntrl.markersize = 3;
PLOTMESH(coord, EleConnTbl, PlotCntrl)

%% 
%%%%%% MATERIALS %%%%%
% Assign materials to elements
EleMat = ones(size(EleConnTbl,1),1); %set default material number of all elements to 1
for iface = 1:length(FACE)
    EleMat(ElementsOnFace{iface}) = MaterialInFace(iface);
end


%% 
%%%%%% Enforce boundary conditions
% Surface traction
 BC_trac = []; % node 1, node 2, x-traction y-traction. One row per edge
if ~isempty(GivenTracOnLine)    
    for iTrac=1:size(GivenTracOnLine,1)
        edges = EdgesOnLine{GivenTracOnLine(iTrac,1)};
        BC_trac = [BC_trac; edges ones(length(edges),1)*GivenTracOnLine(iTrac,2:3)];
    end
end

% Displacement
 BC_disp = []; %node, direction and displacement. One row per DOF
if ~isempty(GivenDispOnLine)
    for iDisp=1:size(GivenDispOnLine,1)
        nodes = NodesOnLine{GivenDispOnLine(iDisp,1)};
        BC_disp = [BC_disp;  nodes ones(size(nodes,1),1)*GivenDispOnLine(iDisp,2:3)];
    end
end

[disp,EleStress]= CVE4304FEASolverElast2D(coord,EleConnTbl,BC_trac,BC_disp,mat,EleMat);
