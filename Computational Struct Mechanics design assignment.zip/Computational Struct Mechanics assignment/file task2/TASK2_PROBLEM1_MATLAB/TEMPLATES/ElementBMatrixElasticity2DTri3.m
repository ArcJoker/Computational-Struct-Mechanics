function B = ElementBMatrixElasticity2DTri3(coordEle)
%% [B]-matrix

x1 = coordEle(1,1); y1 = coordEle(1,2); 
x2 = coordEle(2,1); y2 = coordEle(2,2); 
x3 = coordEle(3,1); y3 = coordEle(3,2); 

a2 = x2*y3-x3*y2 + x3*y1-x1*y3 + x1*y2-x2*y1;
%% to be completed by student
B = 1/a2*[y2-y3 0 y3-y1 0 y1-y2 0; ...
           0 x3-x2 0 x1-x3 0 x2-x1; ...
           x3-x2 y2-y3 x1-x3 y3-y1 x2-x1 y1-y2 ];

end
