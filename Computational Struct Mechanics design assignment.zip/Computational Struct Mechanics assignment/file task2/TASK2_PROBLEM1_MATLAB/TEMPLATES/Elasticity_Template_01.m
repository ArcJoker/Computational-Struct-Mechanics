clear; %clear all variables
close all; %close all figures
warning('off','all'); clc;
dbstop if error

% SET THE PATHS TO THE FOLDERS (to be replaced by student)
addpath(genpath('E:\CVEN 9820 ass\CVEN4304.MTLB.CODE'));

%%                    MATERIAL MODELS - INPUT
%__________________________________________________________________________

% NOTATIONS:
%       mat(N).E     =  YOUNG'S MODULUS
%       mat(N).pos   =  POISSON'S RATIO
%       mat(N).plane 
%                    =  1  :(PLANE STRESS)
%                    =  2  :(PLANE STRAIN)
%
% N - NUMBER FOR MATERIAL MODEL

% > > > > > > > > > > > >INPUT MATERIAL MODEL 1
% >
mat(1).E = 20e6;    %E: Young's modulus
mat(1).pos = 0.3; %pos: Poisson's ratio
mat(1).plane = 2;  %plane = 1: plane stress
                   %      = 2: plane strain



%%                FINITE ELEMENT MODEL - MESH GENERATION
%__________________________________________________________________________

% > > > > > > > > > > > >INPUT: NODAL COORDINATES (ONE ROW PER NODE)
% >
coord = [ 0   0; ...
          0   1; ...
          0   2; ...
          2.8 1; ...
          2.8 2;...
          4.8 2;
          4.8 1];

% > > > > > > > > > > > >INPUT: ELEMENT CONNECTIVITY (ONE ROW PER ELEMENT)
% >
EleConnTbl = [ 2 1 4; ...
               2 4 3; ...
               5 3 4; ...
               5 4 6;
               7 6 4];

% .........................................................................           
           
% * * * * * * * * * PROCESSING: NUMBER OF NODES IN THE MESH     
% *                                 
nNode = size(coord,1);

% * * * * * * * * * PROCESSING: NUMBER OF ELEMENTS IN THE MESH
% *      
nEle = size(EleConnTbl,1);

% * * * * * * * * * PROCESSING: SET PLOT CONTROLS
% *                 PlotCntrl.lettering 
% *                   = 0 (DO NOT SHOW NODE AND ELEMENT NUMBERS)
% *                   = 1 (SHOW NODE AND ELEMENT NUMBERS)
% *
if size(EleConnTbl,1) > 200 
    PlotCntrl.lettering = 0;
else
    PlotCntrl.lettering = 1;
end
PlotCntrl.markersize = 3;

% * * * * * * * * * PROCESSING: PLOT THE MESH
PLOTMESH(coord, EleConnTbl, PlotCntrl)



%%           FINITE ELEMENT MODEL - BOUNDARY CONDITIONS
%__________________________________________________________________________

% > > > > > > > >INPUT: SURFACE TRACTION
% >                FORMAT: ONE ROW PER ELEMENT EDGE
% >                  BC_trac = [NODE 1, NODE 2, X-TRACTION, Y-TRACTION;...];
% >
BC_trac=[5 6 0 -11.6e3];

% > > > > > > > >INPUT: DISPLACEMENT
% >                FORMAT: ONE ROW PER DEGREE OF FREEDOM
% >                  BC_disp = [NODE NUMBER, DIRECTION, VALUE OF DISP;...];
% >
% >                DIRECTION 
% >                    = 1 (X-DEGREE-OF-FREEDOM)
% >                    = 2 (Y-DEGREE-OF-FREEDOM)
% >
BC_disp=[1 1 0; 1 2 0; ...
         2  1 0; 2 2 0; ...
         3 1 0; 3 2 0];



%%                 FINITE ELEMENT MODEL - MATERIALS
%__________________________________________________________________________

% * * * * * * * * * PROCESSING: :ASSIGN MATERIALS TO THE ELEMENTS
% *
EleMat = ones(size(EleConnTbl,1),1); % only one material for this example
  


%% ASSIGNMENT'S TASK: 
%  WRITE A FINITE ELEMENT CODE INSIDE THE GIVEN FUNCTION:
%                  CVE4304FEASolverElast2D
%
% THIS FILE IS ACCESSIBLE IN THE ASSIGNMENT FOLDER AS:
%                CVE4304FEASolverElast2D.m
% 
% ALL THE INSTRUCTIONS TO GUIDE YOU THROUGH THE ASSIGNMENT ARE WRITTEN
% WITHIN

[disp,EleStress]=CVE4304FEASolverElast2D(coord,EleConnTbl,BC_trac,BC_disp,mat,EleMat);

