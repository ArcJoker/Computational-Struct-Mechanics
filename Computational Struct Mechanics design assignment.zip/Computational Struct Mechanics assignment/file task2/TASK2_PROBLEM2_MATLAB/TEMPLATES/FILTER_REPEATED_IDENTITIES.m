function [LIST]=FILTER_REPEATED_IDENTITIES(TEMP)
%**************************************************************************
% THIS FUNCTION FILTERS OUT REPEATED IDENTITIES IN THE INPUT VARIABLE TEMP
%
%
%**************************************************************************
LIST=[];
for I=1:size(TEMP,2);
    N=TEMP(1,I);
    if I==1
        LIST=[LIST N];
    else
        IFLAG=0;
        for J=1:size(LIST,2);
            if N==LIST(1,J)
                IFLAG=1;                % THIS IDENTITY IS ALREADY ENLISTED
            end
        end
        if IFLAG==0
            LIST=[LIST N];
        end
    end
end