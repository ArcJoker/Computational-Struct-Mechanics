function [BNLIST,BCLIST,BELIST]=COLLECT_BOUNDARY_NODES_AND_EDGES...
    (VERTICES,COORD,LINE,EDGES)

SMALL=1E-8;

BNLIST=[];
BELIST=[];
BCLIST=[];

for IL=1:size(LINE,1);
    
    TEMP=[];    
    LCON=LINE(IL,:);
        
    X1=COORD(LCON(1,1),1); Y1=COORD(LCON(1,1),2);
    X2=COORD(LCON(1,2),1); Y2=COORD(LCON(1,2),2);
    
    YMAX=max(Y1,Y2);     YMIN=min(Y1,Y2);
    XMAX=max(X1,X2);     XMIN=min(X1,X2);
    
    for IE=1:size(EDGES,1);
       EDGE=[EDGES(IE,1) EDGES(IE,2)];
        
        KOUNT=0;
        for IEE=1:size(EDGE,2);
            ON_EDGE=0;
            X0=VERTICES(EDGE(1,IEE),1); Y0=VERTICES(EDGE(1,IEE),2);
            
            if abs(X2-X1)<=SMALL
                if abs(X0-X1)<=SMALL
                    ON_EDGE=1;
                end
            else
                YTEMP=(Y2-Y1)*(X0-X1)/(X2-X1)+Y1;
                if abs(YTEMP-Y0)<=SMALL
                    ON_EDGE=1;
                end
            end
            
            if X0>XMAX+SMALL || X0<XMIN-SMALL || Y0>YMAX+SMALL ||...
                    Y0<YMIN-SMALL
                ON_EDGE=0;
            end
            
            if ON_EDGE==1
                KOUNT=KOUNT+1;
            end
        end
        
        if KOUNT==2
            % THE CURRENT EDGE LIES ON THE PRIMARY LINE
            TEMP=[TEMP IE];
        end
    end
    
    % OBTAIN THE NODES ON THIS EDGE
    SCTR=EDGES(TEMP,:);
    ECTR=[];
    for I=1:size(SCTR,1);
        ECTR=[ECTR SCTR(I,:)];
    end
    [SCTR]=FILTER_REPEATED_IDENTITIES(ECTR);        
    NCTR=SCTR;
    SCTR=VERTICES(SCTR,:);  
        
    % SORT THE COORDINATES IN THE ORDER OF THE LINE DEFINED
    if abs(SCTR(1,1)-X1)<=SMALL && abs(SCTR(1,2)-Y1)<=SMALL
        
        % NODE COINCIDENT - DO NOTHING
    else        
        
        % NODE NOT COINCIDENT. REVERSE ORDERING
        VCTR=SCTR;
        NV  =size(VCTR,1);
        SCTR=SCTR(NV:-1:1,:);
        NCTR=NCTR(1,NV:-1:1);
        
    end
    
    BNLIST{IL}=NCTR';
    BCLIST{IL}=SCTR;
    
    % GENERATE EDGELIST FROM NODE LIST
    ECTR=[];
    for J=1:size(NCTR,2)-1;
        ECTR=[ECTR; NCTR(1,J) NCTR(1,J+1)];
    end
    BELIST{IL}=ECTR;
    
end