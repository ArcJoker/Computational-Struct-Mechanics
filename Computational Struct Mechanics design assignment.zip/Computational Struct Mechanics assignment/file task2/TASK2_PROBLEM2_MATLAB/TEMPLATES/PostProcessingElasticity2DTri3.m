function [ EleStress ] = PostProcessingElasticity2DTri3( coord, EleConnTbl, EleMat, mat, disp)
%Post-processing. use "doc patch" to access documentation of "patch" command


figure (10)

disp = reshape(disp,2,length(disp)/2)';
dispMax = max(disp);
dispMin = min(disp);
AA=abs(disp);
[Y_col,Ind_row]=max(AA);

coordMax = max(coord);
coordMin = min(coord);
deform = max((dispMax-dispMin)./(coordMax-coordMin));
magFactor = 0.1/deform;

deformedCoord = coord + magFactor*disp;

nEle = size(EleConnTbl,1);

X = zeros(3,nEle);
Y = zeros(3,nEle);
dispAmp = zeros(3,nEle);
EleStress = zeros(3,nEle);

for ie  = 1:nEle %loop over elements
    
    EleNode = EleConnTbl(ie,:); %element connectivity
    displacedcoordEle = deformedCoord(EleNode,:); %displaced nodal coordinates of an element [ x1 y1; x2 y2; x3 y3]
    X(:,ie) = displacedcoordEle(:,1);
    Y(:,ie) = displacedcoordEle(:,2);
    eleDisp = disp(EleNode,:);
    dispAmp(:,ie) = sqrt(eleDisp(:,1).^2+eleDisp(:,2).^2); %nodal displacement amplitude of an element

    coordEle = coord(EleNode,:); %nodal coordinates of an element [ x1 y1; x2 y2; x3 y3]
    B = ElementBMatrixElasticity2DTri3(coordEle); %B-matrix
    EleStress(:,ie) = mat(EleMat(ie)).D*B*reshape(eleDisp',[],1); %stresses
    
end

colormap(jet)
subplot(221)
patch(X,Y,dispAmp,'EdgeColor','none');
axis equal
title('Displacement amplitude')
colorbar('location','Eastoutside')
subplot(222)
patch(X,Y,EleStress(1,:),'EdgeColor','none')
axis equal
title('Stress \sigma_{xx}')
colorbar('location','Eastoutside')
subplot(223)
patch(X,Y,EleStress(2,:),'EdgeColor','none')
axis equal
title('Stress \sigma_{yy}')
colorbar('location','Eastoutside')
subplot(224)
patch(X,Y,EleStress(3,:),'EdgeColor','none')
axis equal
title('Stress \tau_{xy}')
colorbar('location','Eastoutside')

end

