function [ stff ] = GlobalStiffnessMatrixElasticity2DTri3(  coord, EleConnTbl, EleMat, mat)
%Global stiffness matrix for 2D stress analysis by 3-node triangular element

%%
nNode = size(coord,1);
nEle = size(EleConnTbl,1);

%% Stiffness matrix
stff = zeros(2*nNode,2*nNode);
for ie  = 1:nEle %loop over elements
    EleNode = EleConnTbl(ie,:);
    coordEle = coord(EleNode,:); %nodal coordinates of an element [ x1 y1; x2 y2; x3 y3]
    D = mat(EleMat(ie)).D; %
    
    EleStff = ElementStiffnessMatrixElasticity2D(coordEle, D); %element stiffness matrix
    % assemble global stiffness matrix
    EleDOF = reshape( [ 2*EleNode-1; 2*EleNode], [],1 ); %DOF to DOF connectivity
    stff( EleDOF, EleDOF ) = stff( EleDOF, EleDOF ) + EleStff; 
end

end

