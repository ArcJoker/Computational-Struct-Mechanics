function [disp,EleStress]=CVE4304FEASolverElast2D(coord,EleConnTbl,BC_trac,BC_disp,mat,EleMat)

%%                        INSTRUCTION TO STUDENTS 
% #
% # ASSIGNMENT'S INSTRUCTIONS:
% #   COMPLETE A FINITE ELEMENT CODE TO:
% #    
% #    (1)  COMPUTE THE ELASTICITY MATRICES
% #    (2)  COMPUTE THE GLOBAL STIFFNESS MATRIX OF THE FINITE ELEMENT MESH
% #         
% #  NOTE: THIS FUNCTION APPLIES TO BOTH PROBLEMS 1 AND 2 IN THE PART 2 OF 
% #        YOUR ASSIGNMENT
% #
% #  HINT: YOU MAY USE THE FUNCTION 'CVE4304FEASolverSeepage2D' AS A GUIDE

%%                LIST OF VARIABLES INPUT INTO FUNCTION
% 
%   coord       :   NODAL COORDINATES
%   EleConnTbl  :   ELEMENT CONNECTIVITY TABLE
%   BC_trac     :   SURFACE TRACTION APPLIED ON ELEMENT EDGES
%   BC_disp     :   DISPLACEMENTS APPLIED ON ELEMENT NODES
%   mat         :   MATERIAL MODELS
%   EleMat      :   ELEMENT MATERIAL MODELS

%%         LIST OF VARIABLES THAT ARE OUTPUTS IN THIS FUNCTION

% 
%   disp        : VECTOR OF NODAL DISPLACEMENTS
%                 MATRIX DIMENSIONS : [N BY 1] 
%                 N BEING NUMBER OF DEGREES-OF-FREEDOM OF THE MESH
%
%   StressComp  : MATRIX OF STRESS COMPONENTS IN THE ELEMENTS
%                 MATRIX DIMENSIONS : [3 BY NELE]
%                 NELE BEING THE NUMBER OF ELEMENTS IN THE MESH

%%                 SOLUTION - ELASTICITY MATRICES
%__________________________________________________________________________

% COMPUTE THE ELASTICITY MATRICES OF THE MATERIAL MODELS
for imat = 1:length(mat)
    E = mat(imat).E;
    pos = mat(imat).pos;
    if mat(imat).plane == 1
% <                                                                       >
% <                                                                       >
% <INSTRUCTION: ELASTICITY MATRIX FOR PLANE STRESS                        >
% <                                                                       >
% <  To be completed by student     >
        mat(imat).D = E/(1-pos^2)*[1 pos 0; ...
                                   pos 1 0; ...
                                   0 0 (1-pos)/2];
    else
% <                                                                       >
% <                                                                       >
% <INSTRUCTION: ELASTICITY MATRIX FOR PLANE STRAIN                        >
% <                                                                       >
% <   To be completed by student      

        mat(imat).D = E/((1+pos)*(1-2*pos))*[1-pos pos 0; ...
                                             pos 1-pos 0; ...
                                             0 0 (1-2*pos)/2];
    end
end

%%                 SOLUTION - GLOBAL STIFFNESS MATRIX
%__________________________________________________________________________

stff = GlobalStiffnessMatrixElasticity2DTri3( coord, EleConnTbl, EleMat, mat);

%%                  SOLUTION - ENFORCE BOUNDARY CONDITIONS 
%__________________________________________________________________________

[ stff, RHS ]  = EnforceBoundaryConditionsElasticity2D( stff, coord, BC_trac, BC_disp );

%%               SOLUTION - NODAL DISPLACEMENT VECTOR
%__________________________________________________________________________

disp = sparse(stff)\RHS;

%%          POST-PROCESSING - DISPLACEMENT/STRESS CONTOUR

EleStress = PostProcessingElasticity2DTri3(coord, EleConnTbl, EleMat, mat, disp);


