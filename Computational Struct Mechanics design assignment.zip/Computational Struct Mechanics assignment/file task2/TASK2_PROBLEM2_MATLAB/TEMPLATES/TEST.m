c=[3,4,5];
if ~isempty(c)
    a=0;
else
    a=1;
end
