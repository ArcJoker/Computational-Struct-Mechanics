function [ stff, RHS ] = EnforceBoundaryConditionsElasticity2D( stff, coord, BC_trac, BC_disp )
%Enforce boundary donditions

%%
nNode = size(coord,1);

%% Enforcing boundary conditions
RHS = zeros(2*nNode, 1);
% specified surface traction
if ~isempty(BC_trac)
   for ib = 1:size(BC_trac,1)
       nodes = BC_trac(ib,1:2);
       dcoord = coord(nodes(2),:)-coord(nodes(1),:);
       dist = sqrt(dcoord*dcoord');
       DOF = 2*nodes - 1;
       RHS(DOF) = RHS(DOF) + BC_trac(ib,3)*dist/2;
       DOF = 2*nodes;
       RHS(DOF) = RHS(DOF) + BC_trac(ib,4)*dist/2;
   end
end

% specified displacement
if ~isempty(BC_disp) 
   for ib = 1:size(BC_disp,1)
       idof = 2*(BC_disp(ib,1)-1)+BC_disp(ib,2);
       RHS = RHS - stff(:,idof)*BC_disp(ib,3);
       ftmp = stff(idof,idof);
       stff(:,idof) = 0;
       stff(idof,:) = 0;
       stff(idof,idof) = ftmp;
       RHS(idof) = ftmp*BC_disp(ib,3);
   end
end

end

